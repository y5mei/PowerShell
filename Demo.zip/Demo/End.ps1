#Set-ExecutionPolicy RemoteSigned
Unregister-Event -SourceIdentifier FileCreated